"use client";

import { useState } from "react";
import Header from "@/components/header";
import Hero from "@/components/hero";
import CategoryFilter from "@/components/category-filter";
import ProductGrid from "@/components/product-grid";
import Footer from "@/components/footer";
import { EBOOK_CATEGORIES, SAMPLE_EBOOKS } from "@/lib/data";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredProducts = selectedCategory
    ? SAMPLE_EBOOKS.filter((book) => book.category === selectedCategory)
    : SAMPLE_EBOOKS.slice(0, 8);

  return (
    <main className="min-h-screen bg-white">
      <Header />
      <Hero />

      {/* Featured Products Section */}
      <section id="products" className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Nos E-books
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Découvrez notre sélection de livres numériques soigneusement
              choisis
            </p>
          </div>

          <CategoryFilter
            categories={EBOOK_CATEGORIES}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />

          <ProductGrid products={filteredProducts} />
        </div>
      </section>

      <Footer />
    </main>
  );
}
